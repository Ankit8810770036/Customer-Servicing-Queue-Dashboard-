#include <iostream>
#include <queue>
#include <string>

using namespace std;

int main() {
    queue<string> customerQueue;
    int choice;
    string name;

    while (true) {
        cout << "\n=== Customer Service Queue Dashboard ===\n";
        cout << "1. Add Customer to Queue\n";
        cout << "2. Serve Customer\n";
        cout << "3. Display Queue\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        cin.ignore(); // To clear input buffer after integer input

        switch (choice) {
            case 1:
                cout << "Enter customer name: ";
                getline(cin, name);
                customerQueue.push(name);
                cout << name << " added to the queue.\n";
                break;

            case 2:
                if (!customerQueue.empty()) {
                    cout << "Serving customer: " << customerQueue.front() << endl;
                    customerQueue.pop();
                } else {
                    cout << "Queue is empty.\n";
                }
                break;

            case 3:
                if (customerQueue.empty()) {
                    cout << "Queue is empty.\n";
                } else {
                    queue<string> tempQueue = customerQueue;
                    cout << "Current Queue:\n";
                    int position = 1;
                    while (!tempQueue.empty()) {
                        cout << position++ << ". " << tempQueue.front() << endl;
                        tempQueue.pop();
                    }
                }
                break;

            case 4:
                cout << "Exiting dashboard...\n";
                return 0;

            default:
                cout << "Invalid choice. Try again.\n";
        }
    }

    return 0;
}
